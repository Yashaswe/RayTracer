
#ifndef TEST_GEOMTYPES_H
#define TEST_GEOMTYPES_H

void test_geomtypes();

#endif
