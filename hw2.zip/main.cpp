
// #include "test_geomtypes.h"
#include "test_raytracer.h"
#include <vector>
#include <string>
using namespace std;

int main()
{
	//test_geomtypes();

	test_raytracer("part1", {"scene1", "scene2", "scene3", "scene4"});
    
	return 0;
}
