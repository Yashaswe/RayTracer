#ifndef UTILS_H
#define UTILS_H

const float ZERO = 1e-8;

bool eq_zero(float value);
bool gt_zero(float value);

#endif
